///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>


// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}


/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene rendering
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	{
		bool bReturn = false;

		// texture for plane (table)
		bReturn = CreateGLTexture("U:/CS330Content/Projects/7-1_FinalProjectMilestones/textures/white_marble.jpg", "table");
		// texture for tapered cylinder and torus (mug combo)
		bReturn = CreateGLTexture("U:/CS330Content/Projects/7-1_FinalProjectMilestones/textures/black_texture.jpg", "mug");
		// texture for the keyboard
		bReturn = CreateGLTexture("U:/CS330Content/Projects/7-1_FinalProjectMilestones/textures/keyboard.jpg", "keyboard");
		// white texture for the mouse and the pencil holder
		bReturn = CreateGLTexture("U:/CS330Content/Projects/7-1_FinalProjectMilestones/textures/white_texture.jpg", "white");
		// paper texture for the books
		bReturn = CreateGLTexture("U:/CS330Content/Projects/7-1_FinalProjectMilestones/textures/old_paper.jpg", "paper");
		BindGLTextures();
	}

}

/***********************************************************
  *  DefineObjectMaterials()
  *
  *  This method is used for configuring the various material
  *  settings for all of the objects within the 3D scene.
  ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	/*** STUDENTS - add the code BELOW for defining object materials. ***/
	/*** There is no limit to the number of object materials that can ***/
	/*** be defined. Refer to the code in the OpenGL Sample for help  ***/

	// gives a shiny sheen to the material
	OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	glassMaterial.ambientStrength = 0.3f;
	glassMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	glassMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	glassMaterial.shininess = 85.0;
	glassMaterial.tag = "glass";
	m_objectMaterials.push_back(glassMaterial);

	// reflects much less light than the glass. More matte.
	OBJECT_MATERIAL clayMaterial;
	clayMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.3f);
	clayMaterial.ambientStrength = 0.3f;
	clayMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.5f);
	clayMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.4f);
	clayMaterial.shininess = 0.5;
	clayMaterial.tag = "clay";
	m_objectMaterials.push_back(clayMaterial);

	// set material for the keyboard (white and slightly shiny)
	OBJECT_MATERIAL keyboardMaterial;
	keyboardMaterial.ambientColor = glm::vec3(0.9f, 0.9f, 0.9f);
	keyboardMaterial.ambientStrength = 0.3f;
	keyboardMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	keyboardMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	keyboardMaterial.shininess = 32.0f;
	keyboardMaterial.tag = "keyboard";
	m_objectMaterials.push_back(keyboardMaterial);

	// set material for the mouse (white and slightly shiny)
	OBJECT_MATERIAL mouseMaterial;
	mouseMaterial.ambientColor = glm::vec3(0.9f, 0.9f, 0.9f);
	mouseMaterial.ambientStrength = 0.3f;
	mouseMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	mouseMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	mouseMaterial.shininess = 32.0f;
	mouseMaterial.tag = "mouse";
	m_objectMaterials.push_back(mouseMaterial);

	// darkish material for the pencil's body
	OBJECT_MATERIAL pencilBodyMaterial;
	pencilBodyMaterial.ambientColor = glm::vec3(0.0f, 0.0f, 0.0f);
	pencilBodyMaterial.diffuseColor = glm::vec3(0.0f, 0.0f, 0.0f); // Black
	pencilBodyMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	pencilBodyMaterial.shininess = 10.0f;
	pencilBodyMaterial.tag = "pencilBody";
	m_objectMaterials.push_back(pencilBodyMaterial);

	// the material for the pencil's tip (lighter, more reflective of light)
	OBJECT_MATERIAL pencilTipMaterial;
	pencilTipMaterial.ambientColor = glm::vec3(0.8f, 0.4f, 0.1f);
	pencilTipMaterial.diffuseColor = glm::vec3(0.9f, 0.5f, 0.2f);
	pencilTipMaterial.specularColor = glm::vec3(1.0f, 0.6f, 0.3f);
	pencilTipMaterial.shininess = 64.0f;
	pencilTipMaterial.tag = "pencilTip";
	m_objectMaterials.push_back(pencilTipMaterial);

	// for the monitor stand
	OBJECT_MATERIAL silverMaterial;
	silverMaterial.ambientColor = glm::vec3(0.75f, 0.75f, 0.75f);
	silverMaterial.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	silverMaterial.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);
	silverMaterial.shininess = 32.0f;
	silverMaterial.tag = "silver";
	m_objectMaterials.push_back(silverMaterial);

	// low reflectivity and dark color
	OBJECT_MATERIAL blackMaterial;
	blackMaterial.ambientColor = glm::vec3(0.02f, 0.02f, 0.02f);
	blackMaterial.diffuseColor = glm::vec3(0.01f, 0.01f, 0.01f);
	blackMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
	blackMaterial.shininess = 32.0f;
	blackMaterial.tag = "black";
	m_objectMaterials.push_back(blackMaterial);

	// Dark Blue Material, low reflectivity and dark color
	OBJECT_MATERIAL darkBlueMaterial;
	darkBlueMaterial.ambientColor = glm::vec3(0.0f, 0.0f, 0.3f); 
	darkBlueMaterial.diffuseColor = glm::vec3(0.0f, 0.0f, 0.5f); 
	darkBlueMaterial.specularColor = glm::vec3(0.5f);
	darkBlueMaterial.shininess = 32.0f;
	darkBlueMaterial.tag = "dark_blue";
	m_objectMaterials.push_back(darkBlueMaterial);


	// Dark Grey Material, low reflectivity and dark color
	OBJECT_MATERIAL darkGreyMaterial;
	darkGreyMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	darkGreyMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
	darkGreyMaterial.specularColor = glm::vec3(0.5f);
	darkGreyMaterial.shininess = 32.0f;
	darkGreyMaterial.tag = "dark_grey";
	m_objectMaterials.push_back(darkGreyMaterial);

	// White Material
	OBJECT_MATERIAL whiteMaterial;
	whiteMaterial.ambientColor = glm::vec3(1.0f, 1.0f, 1.0f);  
	whiteMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);  
	whiteMaterial.specularColor = glm::vec3(0.5f);               
	whiteMaterial.shininess = 32.0f;                              
	whiteMaterial.tag = "white";                                  n
	m_objectMaterials.push_back(whiteMaterial);

	

}


/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render 
	// the 3D scene with custom lighting, if no light sources have
	// been added then the display window will be black - to use the 
	// default OpenGL lighting then comment out the following line
	//m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/*** STUDENTS - add the code BELOW for setting up light sources ***/
	/*** Up to four light sources can be defined. Refer to the code ***/
	/*** in the OpenGL Sample for help                              ***/

	m_pShaderManager->setBoolValue("bUseLighting", true);

	// Directional light (sunlight)
	m_pShaderManager->setVec3Value("directionalLight.direction", -0.2f, -0.8f, -0.5f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.5f, 0.5f, 0.5f);
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// Point light 1 (warm light)
	m_pShaderManager->setVec3Value("pointLights[0].position", -4.0f, 8.0f, 0.0f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.6f, 0.4f, 0.2f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	// Point light 2 (cool light)
	m_pShaderManager->setVec3Value("pointLights[1].position", 4.0f, 8.0f, 0.0f);
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.05f, 0.05f, 0.05f);
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 0.2f, 0.4f, 0.6f);
	m_pShaderManager->setVec3Value("pointLights[1].specular", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	// Point light 3 (neutral light)
	m_pShaderManager->setVec3Value("pointLights[2].position", 3.8f, 5.5f, 4.0f);
	m_pShaderManager->setVec3Value("pointLights[2].ambient", 0.05f, 0.05f, 0.05f);
	m_pShaderManager->setVec3Value("pointLights[2].diffuse", 0.5f, 0.5f, 0.5f);
	m_pShaderManager->setVec3Value("pointLights[2].specular", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setBoolValue("pointLights[2].bActive", true);

	// Spotlight (reduced intensity)
	m_pShaderManager->setVec3Value("spotLight.position", 0.0f, 8.0f, 0.0f);
	m_pShaderManager->setVec3Value("spotLight.direction", 0.0f, -1.0f, 0.0f);
	m_pShaderManager->setVec3Value("spotLight.ambient", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("spotLight.diffuse", 0.4f, 0.4f, 0.4f);
	m_pShaderManager->setVec3Value("spotLight.specular", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setFloatValue("spotLight.constant", 1.0f);
	m_pShaderManager->setFloatValue("spotLight.linear", 0.09f);
	m_pShaderManager->setFloatValue("spotLight.quadratic", 0.032f);
	m_pShaderManager->setFloatValue("spotLight.cutOff", glm::cos(glm::radians(30.0f)));
	m_pShaderManager->setFloatValue("spotLight.outerCutOff", glm::cos(glm::radians(35.0f)));
	m_pShaderManager->setBoolValue("spotLight.bActive", true);


}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes in memory to support the 3D scene rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{

	// load the textures for the 3D scene
	LoadSceneTextures();

	// define the materials for objects in the scene
	DefineObjectMaterials();
	// add and define the light sources for the scene
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadPyramid4Mesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadTorusMesh();

}

void SceneManager::DrawPencil(glm::vec3 basePosition, float angleY, float angleZ) {
	const float bodyLength = 0.8f; // Length of pencil body
	const float tipLength = 0.15f;  // Height of pencil tip
	const float radius = 0.05f;     // Radius for both body and tip

	// Create a rotation matrix for both body and tip
	glm::mat4 rotationMatrix = glm::rotate(glm::mat4(1.0f), glm::radians(angleY), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationMatrix = glm::rotate(rotationMatrix, glm::radians(angleZ), glm::vec3(0.0f, 0.0f, 1.0f));

	// Draw pencil body
	glm::mat4 bodyModelMatrix = glm::mat4(1.0f);
	bodyModelMatrix = glm::translate(bodyModelMatrix, basePosition); // Move to base position
	bodyModelMatrix = bodyModelMatrix * rotationMatrix; // Apply rotation
	bodyModelMatrix = glm::scale(bodyModelMatrix, glm::vec3(radius, bodyLength, radius)); // Scale to body size

	if (m_pShaderManager != nullptr) {
		m_pShaderManager->setMat4Value("model", bodyModelMatrix);
	}

	SetShaderMaterial("pencilBody"); // apply shader material
	m_basicMeshes->DrawCylinderMesh(); // draw the actual mesh

	// Draw pencil tip
	glm::vec3 tipPosition = basePosition + glm::vec3(0.0f, bodyLength, 0.0f); // Position at top of body
	glm::mat4 tipModelMatrix = glm::mat4(1.0f);

	// Move to tip position and apply rotation
	tipModelMatrix = glm::translate(tipModelMatrix, tipPosition);
	tipModelMatrix = tipModelMatrix * rotationMatrix;

	// Centering adjustment: move down half of the tip length
	tipModelMatrix = glm::translate(tipModelMatrix, glm::vec3(0.0f, -tipLength * 0.0f, 0.0f));

	// Scale to tip size
	tipModelMatrix = glm::scale(tipModelMatrix, glm::vec3(radius, tipLength, radius));

	if (m_pShaderManager != nullptr) {
		m_pShaderManager->setMat4Value("model", tipModelMatrix);
	}

	SetShaderMaterial("pencilTip");
	m_basicMeshes->DrawConeMesh();
}

void SceneManager::DrawMonitor() {
	// * START stand * 
	// base variables for use in creating the monitor stand
	glm::vec3 standPosition(0.9f, 0.0f, 2.0f);
	float baseWidth = 1.0f;  
	float baseDepth = 0.8f;  
	float baseHeight = 0.05f;
	float stemWidth = 0.8f;  
	float stemDepth = 0.5f;  
	float stemHeight = 0.8f;
	float topWidth = 0.1f;
	float topDepth = 0.1f;

	// Draw wide base
	glm::mat4 baseModel = glm::mat4(1.0f);
	baseModel = glm::translate(baseModel, standPosition);
	baseModel = glm::scale(baseModel, glm::vec3(baseWidth, baseHeight, baseDepth));
	m_pShaderManager->setMat4Value("model", baseModel);
	SetShaderMaterial("silver");
	m_basicMeshes->DrawBoxMesh();

	// Drawing (attempted) tapered stem
	glm::mat4 stemModel = glm::mat4(1.0f);
	stemModel = glm::translate(stemModel, standPosition + glm::vec3(0.0f, baseHeight + stemHeight / 2, 0.0f));
	stemModel = glm::scale(stemModel, glm::vec3(
		stemWidth - (stemWidth - topWidth) / 2, // Average width
		stemHeight,
		stemDepth - (stemDepth - topDepth) / 2  // Average depth
	));
	m_pShaderManager->setMat4Value("model", stemModel);
	m_basicMeshes->DrawBoxMesh();

	// * END stand

	// * START monitor *

	// Monitor dimensions
	// variables to be used in the creation of the monitor
	float monitorWidth = 4.2f;
	float monitorHeight = 2.1f;
	float monitorDepth = 0.05f;
	float bezelThickness = 0.02f;

	// Calculate monitor position based on stand
	glm::vec3 monitorPosition = standPosition + glm::vec3(0.0f, baseHeight + stemHeight + 1.05f, -monitorDepth / 2);

	// Draw monitor frame
	glm::mat4 frameModel = glm::mat4(1.0f);
	frameModel = glm::translate(frameModel, monitorPosition);
	frameModel = glm::scale(frameModel, glm::vec3(monitorWidth, monitorHeight, monitorDepth));
	m_pShaderManager->setMat4Value("model", frameModel);
	SetShaderMaterial("black"); // this applies the small black border that wraps around the screen
	m_basicMeshes->DrawBoxMesh();

	// Draw monitor screen (slightly in front of the frame)
	glm::mat4 screenModel = glm::mat4(1.0f);
	screenModel = glm::translate(screenModel, monitorPosition + glm::vec3(0.0f, 0.0f, monitorDepth / 2 + 0.001f));
	screenModel = glm::scale(screenModel, glm::vec3(monitorWidth - bezelThickness * 2, monitorHeight - bezelThickness * 2, 0.001f));
	m_pShaderManager->setMat4Value("model", screenModel);

	SetShaderMaterial("white"); // use the white material
	SetShaderTexture("glass"); // give the screen amplified reflection
	m_basicMeshes->DrawBoxMesh();

	// * END monitor *
}

void SceneManager::DrawBookStack() {
	// positioning of the book stack
	glm::vec3 stackBasePosition(-4.0f, 0.2f, 4.0f);
	// dimensions of each book
	float bookWidth = 1.0f;
	float bookHeight = 1.4f;
	float bookDepth = 0.3f;
	// colors to be used in the books
	std::vector<std::string> bookColors = { "dark_blue", "dark_grey", "black", "dark_blue", "dark_grey" };
	// place each book where it belongs
	for (int i = 0; i < 5; ++i) {
		glm::mat4 bookModel = glm::mat4(1.0f);
		glm::vec3 bookPosition = stackBasePosition + glm::vec3(0.0f, i * bookDepth, 0.0f);

		bookModel = glm::translate(bookModel, bookPosition);
		// rotate each book slightly
		bookModel = glm::rotate(bookModel, glm::radians(90.0f), glm::vec3(0.05f * i, 0.0f, 1.0f));

		// Draw book covers (front and back faces)
		glm::mat4 coverModel = glm::scale(bookModel, glm::vec3(bookDepth, bookWidth, bookHeight));
		m_pShaderManager->setMat4Value("model", coverModel);
		SetShaderMaterial(bookColors[i]);
		// Draw only front and back faces
		m_basicMeshes->DrawBoxMesh(); 

		// (attempted) Draw book pages (top, bottom, left, right faces)
		glm::mat4 pagesModel = glm::scale(bookModel, glm::vec3(bookDepth * 0.99f, bookWidth * 0.99f, bookHeight * 0.99f));
		m_pShaderManager->setMat4Value("model", pagesModel);
		SetShaderTexture("paper");
		// Draw only side faces
		m_basicMeshes->DrawBoxMesh(); 
	}
}



/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	//set texture before drawing the plane
	SetShaderTexture("table");
	// to adjust texture UV values
	SetTextureUVScale(5.0f, 5.0f);



	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set material
	SetShaderMaterial("glass");
	// draw the mesh with transformation values - this plane is used for the base
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/



	/****************************************************************/
	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

	// Define the mug's new position
	// changed to vertical 1.7 to sit mug onto desk [plane]
	glm::vec3 mugPosition = glm::vec3(-2.0f, 0.9f, 4.0f);  // Moved left and forward
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.4f, 0.8f, 0.4f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 180.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.9f, 0.4f);
	// set the texture on the cylinder
	SetShaderTexture("mug");

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		mugPosition);

	// to adjust texture UV values
	SetTextureUVScale(1.0f, 1.0f);

	//set texture before drawing the mug
	SetShaderMaterial("clay");
	// draw the filled cylinder shape
	m_basicMeshes->DrawTaperedCylinderMesh(true, true, true);
	/****************************************************************/

	/****************************************************************/
	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f); // make the mug handle thick and to correct dimensions 

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f; // rotate it into correct orientation to mimic handle

	// set the XYZ position for the mesh
	positionXYZ = mugPosition + glm::vec3(0.4f, -0.30f, 0.0f);
	// set the texture on the torus
	SetShaderTexture("mug"); // match the mug texture

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// to adjust texture UV values
	SetTextureUVScale(1.0f, 1.0f);

	//set texture before drawing the torus handle
	SetShaderMaterial("clay");
	// draw the filled torus shape
	m_basicMeshes->DrawTorusMesh();
	/****************************************************************/

	/****************************************************************/
	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

	// set the XYZ scale for the keyboard (thin and wide)
	scaleXYZ = glm::vec3(4.0f, 0.05f, 1.5f);

	// set the XYZ rotation for the keyboard (flat on the table)
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the keyboard (to the right of the mug)
	positionXYZ = mugPosition + glm::vec3(3.0f, -0.8f, 0.0f);
	SetTextureUVScale(1.0f, 1.0f);

	// mimic keys with a texture
	SetShaderTexture("keyboard");
	// set the transformations into memory
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	
	SetShaderMaterial("keyboard");

	// draw the keyboard using the box mesh
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	/****************************************************************/
	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

	// * START mouse bottom * 

	// Set the XYZ scale for the mouse
	scaleXYZ = glm::vec3(0.5f, 0.03f, 0.8f);

	// Set the XYZ rotation for the mouse (flat on the table)
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the mouse to the right of the keyboard
	positionXYZ = mugPosition + glm::vec3(6.0f, -0.8f, 0.0f);

	SetShaderTexture("white");
	// Set the transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set material for the mouse (white and slightly shiny)
	SetShaderMaterial("mouse");

	// Draw the mouse using the box mesh
	m_basicMeshes->DrawBoxMesh();

	// * END mouse bottom * 

	// * START mouse top * 

	// Set the XYZ scale for the mouse top (adjust to match the base)
	scaleXYZ = glm::vec3(0.5f, 0.15f, 0.8f);

	// Set the XYZ rotation for the mouse top
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the mouse top slightly above the base
	positionXYZ = mugPosition + glm::vec3(6.0f, -0.8f, 0.0f);

	SetShaderTexture("white");
	// Set the transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set material for the mouse top (same as base)
	SetShaderMaterial("mouse");

	// Draw the mouse top using the half-sphere mesh
	m_basicMeshes->DrawSphereMesh();

	// * END mouse top * 
	// 
	// * START pencil holder
	// Set the XYZ scale for the pencil holder (adjust to match the base)
	scaleXYZ = glm::vec3(0.6f, 1.15f, 0.5f);

	// Set the XYZ rotation for the pencil holder top
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the pencil holder slightly above the base
	positionXYZ = mugPosition + glm::vec3(8.0f, -0.85f, 0.0f);

	SetShaderTexture("white");
	// Set the transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set material for the pencil holder (same as base)
	SetShaderMaterial("mouse");

	// Draw the pencil holder using the half-sphere mesh
	m_basicMeshes->DrawCylinderMesh();


	// * START pencils
	glm::vec3 pencilHolderPosition = positionXYZ; // Assuming this is where your holder is positioned
	DrawPencil(pencilHolderPosition + glm::vec3(0.1f, 1.1f, 0.1f), 5.0f, 0.0f);   // Adjust Y for height above holder
	DrawPencil(pencilHolderPosition + glm::vec3(-0.1f, 1.1f, -0.1f), -3.0f, 0.0f);
	DrawPencil(pencilHolderPosition + glm::vec3(0.2f, 1.1f, -0.2f), 10.f, 0.0f);
	DrawPencil(pencilHolderPosition + glm::vec3(-0.15f, 1.1f, -0.f), -10.f, 0.0f);
	DrawPencil(pencilHolderPosition + glm::vec3(-0.f, 1.1f, -0.15f), -5.f, 0.0f);


	// *END pencils

	// * START monitor stand *

	DrawMonitor();

	// * END monitor stand * 

	// * START book stack *

	DrawBookStack();

	// * END book stack

}

