#ifndef PENCIL_H
#define PENCIL_H

#include <glm/glm.hpp> // Include GLM for vector types
#include "Source/SceneManager.h" // Include SceneManager for material setting

class Pencil {
public:
    // Constructor
    Pencil(glm::vec3 position, float angleY, float angleZ, SceneManager* sceneManager);

    // Method to draw the pencil
    void Draw(ShapeMeshes* meshes);

private:
    glm::vec3 m_position; // Position of the pencil
    float m_angleY;       // Rotation around Y-axis
    float m_angleZ;       // Rotation around Z-axis
    SceneManager* m_sceneManager; // Reference to SceneManager for setting materials
};

#endif // PENCIL_H