#include "Pencil.h"
#include "../../3DShapes/ShapeMeshes.h"
#include "Source/SceneManager.h"

// Constructor implementation
Pencil::Pencil(glm::vec3 position, float angleY, float angleZ, SceneManager* sceneManager)
    : m_position(position), m_angleY(angleY), m_angleZ(angleZ), m_sceneManager(sceneManager) {}

void Pencil::Draw(ShapeMeshes* meshes) {
    const float bodyLength = 0.8f;
    const float tipLength = 0.15f;
    const float radius = 0.05f;

    // Create transformation matrix for the entire pencil
    glm::mat4 modelMatrix = glm::mat4(1.0f);
    modelMatrix = glm::translate(modelMatrix, m_position);
    modelMatrix = glm::rotate(modelMatrix, glm::radians(m_angleY), glm::vec3(0.0f, 1.0f, 0.0f));
    modelMatrix = glm::rotate(modelMatrix, glm::radians(m_angleZ), glm::vec3(0.0f, 0.0f, 1.0f));

    // Draw pencil body
    glm::mat4 bodyModelMatrix = modelMatrix; // Use same transformation
    bodyModelMatrix = glm::scale(bodyModelMatrix, glm::vec3(radius, bodyLength, radius));

    if (m_sceneManager != nullptr) {
        m_sceneManager->SetShaderMaterial("pencilBody"); // Set material for body
        m_sceneManager->setMat4Value("model", bodyModelMatrix);
        meshes->DrawCylinderMesh();
    }

    // Draw pencil tip
    glm::mat4 tipModelMatrix = modelMatrix; // Use same transformation
    tipModelMatrix = glm::translate(tipModelMatrix, glm::vec3(0.0f, bodyLength, 0.0f)); // Position at top of body
    tipModelMatrix = glm::translate(tipModelMatrix, glm::vec3(0.0f, -tipLength * 0.5f, 0.0f)); // Center tip
    tipModelMatrix = glm::scale(tipModelMatrix, glm::vec3(radius, tipLength, radius));

    if (m_sceneManager != nullptr) {
        m_sceneManager->SetShaderMaterial("pencilTip"); // Set material for tip
        m_sceneManager->setMat4Value("model", tipModelMatrix);
        meshes->DrawConeMesh();
    }
}